import java.io.*;
import java.net.*;
import java.util.*;

class Client
{

public static void main(String args[])throws IOException
{
	System.out.println(".......Client........");
	System.out.println("Connect");
	InetAddress addr=InetAddress.getByName("Localhost");
	System.out.println(addr);
	Socket server = new Socket(addr,5000);
	Scanner sc = new Scanner(System.in);	// this will be used to accept i/p from console

	DataInputStream din = new DataInputStream(server.getInputStream());
	DataOutputStream dos = new DataOutputStream(server.getOutputStream());

	System.out.println("Enter the number of frames to be requested to the server");
	int n = sc.nextInt();

	dos.write(n);
	dos.flush();

	System.out.println("Enter the type of trans. Error=1 ; No Error=0");
	int choice = sc.nextInt();
	dos.write(choice);

	int i=j=check=0;

	if(choice==0)
	{
		for(j=0 ; j<n ; j++)
		{
			i = din.read();
			System.out.println("Received frame no: " + i);
			System.out.println("Sending acknowledgement for frame no: "+i);
			dos.write(i);
			dos.flush();
		}
		dos.flush();
	}
	
	else
	{
		for(j=0 ; j<n ; j++)
		{
			i=din.read();
			if(i==check)
			{
				System.out.println("Received frame no: " + i);
				System.out.println("Sending acknowledgement for frame no: " + i);
				dos.write(i);
				check++;
			}
			
			else
			{
				j--;
				System.out.println("Discarded frame no: " + i);
				System.out.println("Sending NEGATIVE ack");
				dos.write(-1);
			}
			dos.flush();
		}
	}

	din.close();
	dos.close();
	server.close();
	System.out.println("Quiting");

	}// end of main method
}// end of main class
