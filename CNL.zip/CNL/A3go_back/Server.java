import java.io.*;
import java.net.*;
import java.util.*;
class Server
{
	public static void main(String args[])throws IOException
{
	System.out.println("...........Server..........");
	System.out.println("Waiting for connection....");
	InetAddress addr=InetAddress.getByName("Localhost");
	ServerSocket ss=new ServerSocket(5000);
	Socket client=new Socket();
	client=ss.accept();

	DataInputStream din = new DataInputStream(client.getInputStream());
	DataOutputStream dos = new DataOutputStream(client.getOutputStream());

	System.out.println("Received request for sending frames..");
	int n = din.read();	//read no. of frames

	boolean check[]=new boolean[n];

	int choice = din.read(); //read choice
	System.out.println("Sending....");
	
	int i;
	if(choice == 0)
	{
		for(i=0 ; i<n ; ++i)
		{
			System.out.println("Sending frame number:  " + i);
			dos.write(i);
			dos.flush();
			System.out.println("Waiting for acknowledgement..");
			
			try
			{
				Thread.sleep(7000);
			}
			catch(Exception e){}

			int ack = din.read();
			System.out.println("Received acknowledgement for frame " + i + " as "+ ack);
		}
		dos.flush();
	}
	
	
	else
	{
		for(i=0 ; i<n ; i++)
		{
			if(i==2)
				System.out.println("Sending frame number:  " + i);
			else
			{
				System.out.println("Sending frame number " + i);
				dos.write(i);
				dos.flush();
				System.out.println("Waiting for acknowledgement ");
				try
				{
					Thread.sleep(7000);
				}
				catch(Exception e){}

				int ack = din.read();

				if(ack!=255)
				{
					System.out.println("Received ack for frame no: " + i + " as "+ack);
					check[i]=true;
				}
			}// end of inner else
		}// end of for

		// check which frames have not been ack

		for(i=0 ; i<n ; i++)
		{
			if(check[i] == false)
			{
				System.out.println("Resending frame "+ i);
				dos.write(i);
				dos.flush();
				System.out.println("Waiting for ack ");
				try
				{
					Thread.sleep(7000);
				}
				catch(Exception e){}

				int ack_new = din.read();
				System.out.println("Received ack for frame no: " + i +" as "+ ack_new);
				check[i]=true;
			}
		}
		dos.flush();
	}// end of else which is for error 

	din.close();
	dos.close();
	client.close();
	ss.close();
	System.out.println("Quiting");

	}// end main method
}// end main class
