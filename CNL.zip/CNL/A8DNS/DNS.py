import socket


print("1. URL to IP")
print("2. IP to URL")
print("Enter your choice: ")
choice=input()

if choice==1:
    url = " "
    url = raw_input("Enter the URL: ")
    print(url)
    ip = socket.gethostbyname(url)		#returns ipv4address
    print(ip)

else:   
    ip = " "  
    ip = raw_input("Enter IP address: ")	
    print(ip)
    try:
    	url = socket.gethostbyaddr(ip)		#returns hostname, alias host name, ip addr of host
    	print(url)
    except socket.herror:
    	print("Valid PTR doesn't exist for given domain. Reverese DNS lookup failed!")
		
