import java.io.*;
import java.net.*;
import java.util.*;

public class Server
{
	public static void main(String args[])throws IOException
	{
		System.out.println("...........Server..........");
		System.out.println("Waiting for connection....");
		InetAddress addr = InetAddress.getByName("Localhost");
		int a[] = { 10, 20, 30, 40, 50, 60, 70, 80 }, i;
		ServerSocket ss=new ServerSocket(5000);
		Socket client=new Socket();
		client=ss.accept();

		DataInputStream dis = new DataInputStream(client.getInputStream());
		DataOutputStream dos = new DataOutputStream(client.getOutputStream());

			System.out.println("The number of frames sent are: " + a.length);
			int n = a.length;
			dos.write(n);
			dos.flush();
			for (i = 0; i<n ; i++) 
			{
				System.out.println("Sent frame no. " + (i+1) + " is: " + a[i]);
				if(i==3 || i==6 || i==7)	//frames corrupted while sending
					dos.write(0);
				else
					dos.write(a[i]);
				dos.flush();
				try { Thread.sleep(7000); }
				catch(Exception e) {}
			}
			
			for(i=0 ; i<n ; i++)
			{
				try { Thread.sleep(7000); }
				catch(Exception e) {}
				int ack = dis.read();	//receive ack
				System.out.println("Acknowledgement received for frame " + (i+1) + " : " + ack);
				if(ack == 0)
				{
					System.out.println("Sending frame " + (i+1) + " again!");
					dos.write(a[i]);	//send frame again
					dos.flush();
				}
				
			}

	dis.close();
	dos.close();
	client.close();
	ss.close();
	System.out.println("Quiting");

	}// end main method
}// end main class