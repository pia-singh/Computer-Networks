import java.util.*;
import java.net.*;
import java.io.*;

class Client
{
	public static void main(String[] argrs) throws Exception
	{
		try 
		{
			int a[] = new int[8], i;
			System.out.println(".......Client........");
			System.out.println("Connect");
			InetAddress addr=InetAddress.getByName("Localhost");
			System.out.println(addr);
			Socket server = new Socket(addr,5000);

			DataInputStream dis = new DataInputStream(server.getInputStream());
			DataOutputStream dos = new DataOutputStream(server.getOutputStream());

			int n = dis.read();
			System.out.println("The number of frames received are: " + n);
			
			for (i = 0; i < n; i++)
			{
				try { Thread.sleep(7000); }
				catch(Exception e) {}
				a[i] = dis.read();		//receive all frames
				System.out.println("Received frame no. " + (i+1) + " is: " + a[i]);
				
			}
		

			for(i=0 ; i<n ; i++)
			{
				System.out.println("Acknowledgement sent for frame no. " + (i+1));
				dos.write(a[i]);	//send ack
				dos.flush();
				if(a[i] == 0)
				{
					System.out.println("Request to retransmit frame no. "+ (i+1) + " again!");
					a[i] = dis.read();	//recieve frame again
					System.out.println("Received frame is: " + a[i]);
				}
				try { Thread.sleep(7000); }
				catch(Exception e) {}
			}
			dis.close();
			dos.close();
			server.close();

		}
		
		catch (Exception e) 
		{
			System.out.println(e);
		}
	}	
}