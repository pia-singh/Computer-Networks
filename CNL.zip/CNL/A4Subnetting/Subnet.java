import java.util.Scanner;
import java.net.InetAddress;

class Subnet
{
	public static void main(String args[])
  {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter the ip address: ");
	String ip = sc.nextLine();
	String split_ip[] = ip.split("\\."); //Split the string after every . and \\ to escape the special characters . and backslash
	//it splits the ip and stores it in a 1D array
	//for eg 172.168.4.5 => split_ip[0] = 172 and split_ip[1]=168 and so on..
	String split_bip[] = new String[4]; //create new string to store splitted binary ip parts in an array
	String bip = "";	//initialise string with empty string
	for(int i=0;i<4;i++)
	{
// "18" => 18 => 10010 => 00010010
		split_bip[i] = appendZeros(Integer.toBinaryString(Integer.parseInt(split_ip[i]))); 
		//appendZeros is user defined function
		//toBinaryString converst given string to binary string
		//Integer.toBinaryString converts it to integer
		//parseInt returns the Int part of specified string
		bip += split_bip[i]+".";
	}
	
	System.out.println("\n IP in binary is "+bip);
	System.out.print("\n Enter the number of sub-networks: ");
	int n = sc.nextInt();

//Calculation of number of bits for subnet addressing:
// bits = (log n)/(log 2);   
/*eg if n = 120, log 120/log 2  gives=> 6.9068, ceil gives us upper integer i.e. 7 */
	int bits = (int)Math.ceil(Math.log(n)/Math.log(2)); 

	System.out.println("\n Number of bits required for sub-network addressing = "+bits);

	int[] arr=new int[32];
    for(int i=0;i<32;i++)
     {
        arr[i]=1;
     }

    int cc = Integer.parseInt(split_ip[0]);
    String mask = null;
	int x =0;
	//this if block determines class of ip and the number of bits to mask
	if(cc>=1 && cc<=223)
        {
            if(cc<=127)					//Class A
            {         
				mask = "255.0.0.0";
              	x = 8+bits;
            }
            if(cc>=128 && cc<=191)		//Class B
            {
                mask = "255.255.0.0";
                x = 16+bits;                
            }
            if(cc>=192)					//Class C
            {
                mask = "255.255.255.0";
                 x = 24+bits;                
            }
		
		
		for(int i=x;i<32;i++)
        	arr[i]=0;				//mask the required number of bits i.e. x
            
        }
    

		System.out.println("\n The default subnet mask is = "+mask);
		System.out.println("\n The subnet mask is = ");
        for(int i=0;i<32;i++)
        {
        	System.out.print(arr[i]);
        }

}


public static String appendZeros(String s)
 {
	String temp = new String("00000000");
	return temp.substring(s.length())+ s;
	//for eg 5 => 101
	//returns 00000 + 101
 }


}


/*

student@student-OptiPlex-3020:~/SYK$ javac Subnet.java 
student@student-OptiPlex-3020:~/SYK$ java Subnet
Enter the ip address: 172.168.12.15

 IP in binary is 10101100.10101000.00001100.00001111

 Enter the number of sub-networks: 3

 Number of bits required for sub-network addressing = 2

 The default subnet mask is = 255.255.0.0

 The Subnet mask is = 11111111.11111111.00000000.00000000
student@student-OptiPlex-3020:~/SYK$ java Subnet
Enter the ip address: 116.12.13.5

 IP in binary is 01110100000011000000110100000101

 Enter the number of sub-networks: 6


 Number of bits required for sub-network addressing = 3

 The subnet mask is = 255.0.0.0

 Subnet address is = 116.12.13.0
student@student-OptiPlex-3020:~/SYK$ java Subnet
Enter the ip address: 202.35.34.1

 IP in binary is 11001010001000110010001000000001

 Enter the number of sub-networks: 10

 Number of bits required for sub-network addressing = 4

 The subnet mask is = 255.255.255.0

 Subnet address is = 202.35.34.0
*/
