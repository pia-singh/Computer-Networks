//============================================================================
// Name        : Hamming.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
    int DataS[11];
    int DataR[12],i;
    int c,c1,c2,c3,c4;

    cout<<"####### HAMMING CODE #######";
    cout<<"\nEnter 7 bit data to be transmitted one by one : \n";
    cin>>DataS[10];
    cin>>DataS[9];
    cin>>DataS[8];
    cin>>DataS[6];
    cin>>DataS[5];
    cin>>DataS[4];
    cin>>DataS[2];

    cout<<"\n\n-----------------------------Calculation of even parity-----------------------------\n";

    DataS[0]=/*DataS[0]^*/DataS[2]^DataS[4]^DataS[6]^DataS[8]^DataS[10];	/*We are finding data at position 1 therefore commented*/
    cout<<"\nP1 : "<<DataS[0];

    DataS[1]=/*DataS[1]^*/DataS[2]^DataS[5]^DataS[6]^DataS[9]^DataS[10];	/*We are finding data at position 2 therefore commented*/
    cout<<"\nP2 : "<<DataS[1];

    DataS[3]=/*DataS[3]^*/DataS[4]^DataS[5]^DataS[6];			/*We are finding data at position 4 therefore commented*/
    cout<<"\nP4 : "<<DataS[3];

    DataS[7]=/*DataS[7]^*/DataS[8]^DataS[9]^DataS[10];			/*We are finding data at position 8 therefore commented*/
    cout<<"\nP8 : "<<DataS[7];

    cout<<"\n\nEncoded data is : ";

    for(i=10;i>=0;i--)
        cout<<DataS[i];

	cout<<"\n--------------------------------------------------------------------------------------------------";
	
	cout<<"\n\nEnter received data bits one by one : \n";

	    for(i=10;i>=0;i--)
	        cin>>DataR[i];
	
	//Hamming code is linear error detecting. It can detect 2 errors and correct only one error
	//1 = odd parity
	//0 = even parity 
	
   	c1=DataR[0]^DataR[2]^DataR[4]^DataR[6]^DataR[8]^DataR[10];

    c2=DataR[1]^DataR[2]^DataR[5]^DataR[6]^DataR[9]^DataR[10];

    c3=DataR[3]^DataR[4]^DataR[5]^DataR[6];
    
    c4=DataR[7]^DataR[8]^DataR[9]^DataR[10];
   	
    c=c4*8+c3*4+c2*2+c1 ;

    if(c==0)
    {
        cout<<"\nNo error while transmission of data!\n";
    }

	else
	{
		cout<<"\nError on position "<<c;
        	
		cout<<"\nData sent : ";
      		for(i=10;i>=0;i--)
        	    cout<<DataS[i];

        	cout<<"\nData received : ";
        	for(i=10;i>=0;i--)
        	   cout<<DataR[i];

		cout<<"\n--------------------------------------------------------------------------------------------------";

        	cout<<"\nCorrect message is : ";

        	//if error bit is 0 we complement it else vice versa
        	
		if(DataR[c-1]==0)
			DataR[c-1]=1;
       		else
			DataR[c-1]=0;

        	for(i=10;i>=0;i--)
		    {
     	  		cout<<DataR[i];
        	}
    }

    return 0;

}


/*
************************************************************************************
                             OUTPUT
************************************************************************************

####### HAMMING CODE #######
Enter 7 bit data to be transmitted one by one : 
1
0
0
1
1
0
1


-----------------------------Calculation of even parity-----------------------------

P1 : 1
P2 : 0
P3 : 0
P4 : 1

Encoded data is : 10011100101
--------------------------------------------------------------------------------------------------

Enter received data bits one by one : 
1
1
0
1
1
1
0
0
1
0
1

Error on position 10
Data sent : 10011100101
Data received : 11011100101
--------------------------------------------------------------------------------------------------
Correct message is : 10011100101


*/
